using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AWS
{
    public class AWSAuth
    {
        public string access_key;
        public string secret_key;
    }
}

